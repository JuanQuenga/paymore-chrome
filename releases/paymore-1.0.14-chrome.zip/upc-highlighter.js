var upcHighlighter=(function(){"use strict";function v(o){return o}const y={matches:["<all_urls>"],runAt:"document_idle",allFrames:!0,main(){const o=(...e)=>{try{console.log("[Paymore UPC Highlighter]",...e)}catch{}},l=/\b(\d{12})\b/g,f=`
      .paymore-upc-highlight {
        background-color: rgba(37, 99, 235, 0.15);
        border-bottom: 2px dotted #2563eb;
        cursor: pointer;
        padding: 1px 2px;
        border-radius: 2px;
        transition: all 0.2s ease;
        position: relative;
      }

      .paymore-upc-highlight:hover {
        background-color: rgba(37, 99, 235, 0.25);
        border-bottom-style: solid;
      }

      .paymore-upc-copied {
        background-color: rgba(16, 185, 129, 0.2) !important;
        border-bottom-color: #10b981 !important;
      }

      .paymore-upc-tooltip {
        position: fixed;
        background-color: #111827;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        z-index: 2147483647;
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.2s ease;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
      }

      .paymore-upc-tooltip.show {
        opacity: 1;
      }
    `,C=()=>{if(!document.getElementById("paymore-upc-highlighter-styles")){const e=document.createElement("style");e.textContent=f,e.id="paymore-upc-highlighter-styles",(document.head||document.documentElement).appendChild(e)}},u=(e,i)=>{document.querySelectorAll(".paymore-upc-tooltip").forEach(a=>{a.remove()});const t=document.createElement("div");t.className="paymore-upc-tooltip",t.textContent=i,document.body.appendChild(t);const n=e.getBoundingClientRect(),c=t.getBoundingClientRect();let r=n.left+n.width/2-c.width/2,s=n.top-c.height-8;r<5&&(r=5),r+c.width>window.innerWidth-5&&(r=window.innerWidth-c.width-5),s<5&&(s=n.bottom+8),t.style.left=`${r}px`,t.style.top=`${s}px`,setTimeout(()=>{t.classList.add("show")},10),setTimeout(()=>{t.classList.remove("show"),setTimeout(()=>{t.remove()},200)},2e3)},E=async(e,i)=>{try{await navigator.clipboard.writeText(e),i.classList.add("paymore-upc-copied"),u(i,"UPC copied!"),setTimeout(()=>{i.classList.remove("paymore-upc-copied")},2e3),o("UPC code copied to clipboard:",e)}catch(t){o("Failed to copy UPC code:",t),u(i,"Failed to copy")}},w=e=>{const i=e.textContent;if(!i||!l.test(i))return;const t=document.createDocumentFragment();let n=0,c;for(l.lastIndex=0;(c=l.exec(i))!==null;){c.index>n&&t.appendChild(document.createTextNode(i.substring(n,c.index)));const r=document.createElement("span"),s=c[0];r.className="paymore-upc-highlight",r.textContent=s,r.setAttribute("data-upc",s),r.title=`Click to copy UPC: ${s}`,r.addEventListener("click",a=>{a.preventDefault(),a.stopPropagation();const p=a.currentTarget.getAttribute("data-upc");E(p,r)}),r.addEventListener("mouseenter",()=>{r.classList.contains("paymore-upc-copied")||u(r,"Click to copy UPC")}),t.appendChild(r),n=c.index+c[0].length}n<i.length&&t.appendChild(document.createTextNode(i.substring(n))),t.childNodes.length>0&&e.parentNode.replaceChild(t,e)},h=e=>{if(!(e.nodeType===Node.ELEMENT_NODE&&(e.tagName==="SCRIPT"||e.tagName==="STYLE"||e.tagName==="NOSCRIPT"||e.classList.contains("paymore-upc-highlight")))){if(e.nodeType===Node.TEXT_NODE){w(e);return}e.childNodes&&Array.from(e.childNodes).forEach(h)}},g=()=>{document.body&&h(document.body)},x=()=>{const e=new MutationObserver(i=>{i.some(n=>n.type==="childList"&&n.addedNodes.length>0||n.type==="characterData")&&setTimeout(g,100)});return document.body&&e.observe(document.body,{childList:!0,subtree:!0,characterData:!0}),e},T=e=>{try{chrome.storage.sync.get(["cmdkSettings"],i=>{if(chrome.runtime.lastError){o("Error checking settings:",chrome.runtime.lastError),e(!0);return}const n=i.cmdkSettings?.upcHighlighter?.enabled??!0;e(n)})}catch(i){o("Failed to check settings:",i),e(!0)}},m=()=>{T(e=>{if(!e){o("UPC highlighting is disabled in settings");return}window===window.top&&o("Initializing UPC highlighter"),C(),setTimeout(g,500);const i=x();try{chrome.runtime.onMessage.addListener((t,n,c)=>{if(t.action==="upc-highlighter-settings-changed")if(t.enabled??!0)o("UPC highlighting re-enabled, reloading page"),location.reload();else{document.querySelectorAll(".paymore-upc-highlight").forEach(a=>{const p=a.parentNode;p&&p.replaceChild(document.createTextNode(a.textContent),a)});const s=document.getElementById("paymore-upc-highlighter-styles");s&&s.remove(),i&&i.disconnect(),o("UPC highlighting disabled")}return!0})}catch(t){o("Failed to set up message listener:",t)}})};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",m):m()}};function P(){}function d(o,...l){}const b={debug:(...o)=>d(console.debug,...o),log:(...o)=>d(console.log,...o),warn:(...o)=>d(console.warn,...o),error:(...o)=>d(console.error,...o)};return(async()=>{try{return await y.main()}catch(o){throw b.error('The unlisted script "upc-highlighter" crashed on startup!',o),o}})()})();
upcHighlighter;