var ebaySoldSummary=(function(){"use strict";function J(t){return t}const N={matches:["https://www.ebay.com/sch/*"],runAt:"document_idle",allFrames:!1,main(){if(!window.location.hostname.includes("ebay.com")||!window.location.pathname.startsWith("/sch/")){console.log("💙 [Paymore eBay Sold Summary] Not on eBay search page, exiting");return}console.log("💙 [Paymore eBay Sold Summary] SCRIPT LOADED - Version 2");const t="paymore-ebay-sold-summary",S="paymore-ebay-sold-summary-style";let E=!1,x=!1;const r=(...e)=>{try{console.log("[Paymore eBay Sold Summary]",...e)}catch{}},O=()=>{if(document.getElementById(S))return;const e=document.createElement("style");e.id=S,e.textContent=`
        #${t} {
          width: 100%;
          border: 1px solid #22c55e;
          background: rgba(34, 197, 94, 0.08);
          padding: 14px 18px;
          border-radius: 10px;
          margin: 12px 0 0 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
          color: #0f172a;
          box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08);
          position: relative;
        }
        #${t} h2 {
          font-size: 17px;
          margin: 0 0 10px;
          font-weight: 600;
          color: #1e293b;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        #${t} h2 img {
          width: 20px;
          height: 20px;
        }
        #${t} .paymore-ebay-summary__metrics {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
        }
        #${t} .paymore-ebay-summary__metric {
          min-width: 120px;
          background: rgba(255, 255, 255, 0.6);
          padding: 10px 12px;
          border-radius: 8px;
          border: 1px solid rgba(148, 163, 184, 0.4);
        }
        #${t} .paymore-ebay-summary__metric--clickable {
          cursor: pointer;
          transition: all 0.2s ease;
        }
        #${t} .paymore-ebay-summary__metric--clickable:hover {
          background: rgba(34, 197, 94, 0.15);
          border-color: rgba(34, 197, 94, 0.6);
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(34, 197, 94, 0.2);
        }
        #${t} .paymore-ebay-summary__metric--clickable:active {
          transform: translateY(0);
          box-shadow: 0 2px 6px rgba(34, 197, 94, 0.3);
        }
        #${t} .paymore-ebay-summary__metric strong {
          display: block;
          font-size: 16px;
          margin-bottom: 4px;
        }
        #${t} .paymore-ebay-summary__metric-button {
          min-width: 120px;
          background: linear-gradient(135deg, rgba(34, 197, 94, 0.95), rgba(21, 128, 61, 0.95));
          padding: 12px 16px;
          border-radius: 8px;
          border: 1px solid rgba(34, 197, 94, 0.6);
          cursor: pointer;
          transition: all 0.2s ease;
          text-align: center;
          color: white;
          font-weight: 600;
          font-size: 13px;
          box-shadow: 0 2px 8px rgba(21, 128, 61, 0.2);
          display: flex;
          align-items: center;
          justify-content: center;
        }
        #${t} .paymore-ebay-summary__metric-button:hover {
          background: linear-gradient(135deg, rgba(21, 128, 61, 1), rgba(20, 83, 45, 1));
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(21, 128, 61, 0.35);
          border-color: rgba(20, 83, 45, 0.8);
        }
        #${t} .paymore-ebay-summary__metric-button:active {
          transform: translateY(0);
          box-shadow: 0 2px 6px rgba(21, 128, 61, 0.3);
        }
        #${t} .paymore-ebay-summary__metric-button[disabled] {
          background: rgba(148, 163, 184, 0.3);
          color: rgba(71, 85, 105, 0.6);
          cursor: not-allowed;
          opacity: 0.5;
          pointer-events: none;
        }
        #${t} .paymore-ebay-summary__metric-button[disabled]:hover {
          transform: none;
          box-shadow: none;
        }
        #${t} .paymore-ebay-summary__dismiss {
          position: absolute;
          top: 10px;
          right: 10px;
          background: rgba(148, 163, 184, 0.2);
          border: 1px solid rgba(148, 163, 184, 0.4);
          border-radius: 6px;
          width: 28px;
          height: 28px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          line-height: 1;
          color: #475569;
          transition: all 0.2s ease;
          z-index: 10;
          pointer-events: auto;
        }
        #${t} .paymore-ebay-summary__dismiss:hover {
          background: rgba(239, 68, 68, 0.9);
          border-color: rgba(220, 38, 38, 0.8);
          color: white;
        }
        #${t} .paymore-ebay-summary__settings {
          position: absolute;
          top: 10px;
          right: 46px;
          background: rgba(148, 163, 184, 0.2);
          border: 1px solid rgba(148, 163, 184, 0.4);
          border-radius: 6px;
          width: 28px;
          height: 28px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          line-height: 1;
          color: #475569;
          transition: all 0.2s ease;
          z-index: 10;
          pointer-events: auto;
        }
        #${t} .paymore-ebay-summary__settings:hover {
          background: rgba(34, 197, 94, 0.9);
          border-color: rgba(21, 128, 61, 0.8);
          color: white;
        }
        #${t} .paymore-ebay-summary__meta {
          margin-top: 12px;
          font-size: 12px;
          color: #475569;
        }
        .paymore-listing-highlight {
          animation: paymore-highlight-pulse 1s ease-in-out;
          outline: 3px solid rgba(34, 197, 94, 0.8) !important;
          outline-offset: 4px;
          border-radius: 8px !important;
          background: rgba(34, 197, 94, 0.05) !important;
        }
        @keyframes paymore-highlight-pulse {
          0%, 100% {
            outline-color: rgba(34, 197, 94, 0.8);
            outline-width: 3px;
          }
          50% {
            outline-color: rgba(21, 128, 61, 1);
            outline-width: 5px;
          }
        }
      `,document.head.appendChild(e)},P=()=>{try{const e=new URL(window.location.href);if(!/\.ebay\./i.test(e.hostname)||!e.pathname.startsWith("/sch/"))return!1;const n=e.searchParams.get("LH_Sold");return n==="1"||n==="true"}catch{return!1}},z=e=>{if(!e)return null;let n=e.replace(/\(.*?\)/g,"").replace(/Approximately\s+/i,"").replace(/About\s+/i,"").trim();const a=n.split(/\bto\b|-/i);a.length>1&&(n=a[0]);const i=n.match(/[\d,.]+/);if(!i)return null;const u=parseFloat(i[0].replace(/,/g,""));return Number.isFinite(u)?u:null},H=e=>{if(!e)return"$";const n=e.replace(/[\d.,]/g,"").replace(/\s+/g," ").trim();if(n)return n;const a=e.match(/[$\u00a3\u00a5\u20ac]/);return a?a[0]:"$"},w=(e,n)=>{const a=e.toLocaleString(void 0,{minimumFractionDigits:2,maximumFractionDigits:2});return`${n?n+" ":""}${a}`.trim()},Y=e=>{try{const n=e.querySelector(".su-styled-text.positive")||e.querySelector(".s-item__title--tagblock .POSITIVE")||e.querySelector(".s-item__ended-date");if(!n)return null;const a=n.textContent?.trim();if(!a)return null;const i=a.match(/Sold\s+([A-Za-z]+\s+\d{1,2},\s+\d{4})/i);if(!i)return null;const u=i[1],g=new Date(u);return isNaN(g.getTime())?null:g}catch{return null}},V=()=>{const e=document.querySelector("ul.srp-results.srp-grid")||document.querySelector("#srp-river-results");if(!e)return r("⚠️ Could not find main results container"),{prices:[],currencyPrefix:"$",mostRecentDate:null,minElement:null,maxElement:null,mostRecentElement:null};r("✓ Found main results container");const n=Array.from(e.children).filter(s=>s.tagName==="LI");r("Found",n.length,"total <li> elements");const a=[];for(let s=0;s<n.length;s++){const l=n[s];if(l.hasAttribute("data-listingid")){a.push(l);continue}const y=l.className||"",h=l.textContent||"";if(y.includes("srp-river-answer--REWRITE_START")||h.includes("Results matching fewer words")){r("🛑 STOP: Found 'fewer words' divider at index",s),r("   - Collected",a.length,"products before divider");break}r("Skipping divider/notice at index",s)}r("✅ Final count:",a.length,"product listings");const i=[];let u=null;for(const s of a){const l=s.querySelector(".s-card__price")||s.querySelector(".s-item__price")||s.querySelector("[data-test-id='ITEM-PRICE']");if(!l)continue;const y=l.textContent?.trim();if(!y)continue;const h=z(y);if(h===null)continue;u||(u=H(y));const v=Y(s);i.push({value:h,element:s,date:v})}if(r("💰 Extracted",i.length,"prices"),i.length===0)return{prices:[],currencyPrefix:u||"$",mostRecentDate:null,minElement:null,maxElement:null,mostRecentElement:null};const g=i.reduce((s,l)=>l.value<s.value?l:s),k=i.reduce((s,l)=>l.value>s.value?l:s),c=i.filter(s=>s.date!==null);let d=null,p=null;c.length>0&&(d=c.reduce((s,l)=>l.date>s.date?l:s),p=d.date);const C=i.map(s=>s.value);return r("📅 Found",c.length,"dates"),{prices:C,currencyPrefix:u||"$",mostRecentDate:p,minElement:g.element,maxElement:k.element,mostRecentElement:d?.element||null}},b=()=>{const e=document.getElementById(t);e&&e.remove()},W=()=>{let e=document.getElementById(t);if(e)return r("✓ Summary container already exists"),e;const n=document.querySelector(".srp-controls__row-2");if(r("Searching for .srp-controls__row-2:",n?"FOUND":"NOT FOUND"),n)return e=document.createElement("section"),e.id=t,n.appendChild(e),r("✓ Summary container inserted into .srp-controls__row-2"),e;const a=document.getElementById("srp-river-results");return r("Fallback: Searching for #srp-river-results:",a?"FOUND":"NOT FOUND"),!a||!a.parentElement?(r("✗ Cannot insert summary - no suitable parent found"),null):(e=document.createElement("section"),e.id=t,a.parentElement.insertBefore(e,a),r("✓ Summary container inserted before #srp-river-results (fallback)"),e)},L=async()=>{E=!1,r("=== renderSummary called ===");try{if(!((await chrome.storage.sync.get(["cmdkSettings"])).cmdkSettings?.ebaySummary?.enabled??!0)){r("✗ eBay Summary feature is disabled in settings"),b();return}}catch(o){r("⚠️ Failed to check settings, assuming enabled",o)}const e=P();if(r("Is sold results page?",e),!e){b();return}if(x){r("✗ Summary was dismissed by user, not showing"),b();return}const{prices:n,currencyPrefix:a,mostRecentDate:i,minElement:u,maxElement:g,mostRecentElement:k}=V();if(r("Collected prices:",n.length,"prices found"),!n.length){r("✗ No prices found, removing summary"),b();return}O();const c=W();if(!c){r("✗ Could not create/find container");return}const d=[...n].sort((o,m)=>o-m),p=n.length,s=n.reduce((o,m)=>o+m,0)/p,l=p%2===1?d[(p-1)/2]:(d[p/2-1]+d[p/2])/2,y=d[0],h=d[d.length-1];let v="N/A";if(i){const o={month:"short",day:"numeric",year:"numeric"};v=i.toLocaleDateString("en-US",o)}const R=new URL(window.location.href).searchParams.get("LH_ItemCondition"),j=R==="4",Q=R==="3",Z=chrome.runtime.getURL("assets/images/brand.png");c.innerHTML=`
        <button type="button" class="paymore-ebay-summary__settings" title="Settings" data-action="settings">⚙</button>
        <button type="button" class="paymore-ebay-summary__dismiss" title="Dismiss" data-action="dismiss">×</button>
        <h2><img src="${Z}" alt="Paymore" /> Paymore Price Summary</h2>
        <div class="paymore-ebay-summary__metrics">
          <div class="paymore-ebay-summary__metric">
            <strong>Average</strong>
            <span>${w(s,a)}</span>
          </div>
          <div class="paymore-ebay-summary__metric">
            <strong>Median</strong>
            <span>${w(l,a)}</span>
          </div>
          <div class="paymore-ebay-summary__metric paymore-ebay-summary__metric--clickable" data-scroll-to="highest" title="Click to scroll to listing">
            <strong>Highest</strong>
            <span>${w(h,a)}</span>
          </div>
          <div class="paymore-ebay-summary__metric paymore-ebay-summary__metric--clickable" data-scroll-to="lowest" title="Click to scroll to listing">
            <strong>Lowest</strong>
            <span>${w(y,a)}</span>
          </div>
          <div class="paymore-ebay-summary__metric">
            <strong>Listings</strong>
            <span>${p}</span>
          </div>
          <div class="paymore-ebay-summary__metric paymore-ebay-summary__metric--clickable" data-scroll-to="latest" title="Click to scroll to listing">
            <strong>Last Sold</strong>
            <span>${v}</span>
          </div>
          <div class="paymore-ebay-summary__metric-button" data-action="view-used" ${j?"disabled":""}>
            View Used
          </div>
          <div class="paymore-ebay-summary__metric-button" data-action="view-new" ${Q?"disabled":""}>
            View New
          </div>
        </div>
        <div class="paymore-ebay-summary__meta">
          Based on ${p} sold listings detected on this page. Apply filters or refresh to recalculate.
        </div>
      `;const I=c.querySelector('[data-action="settings"]'),B=c.querySelector('[data-action="dismiss"]'),F=c.querySelector('[data-action="view-used"]'),q=c.querySelector('[data-action="view-new"]');I&&I.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),r("Settings button clicked"),chrome.runtime.sendMessage({action:"open-settings",section:"ebay"})}),B&&B.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),r("Dismiss button clicked"),x=!0,b()}),F&&F.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation();const m=new URL(window.location.href);m.searchParams.set("LH_ItemCondition","4"),window.location.href=m.toString()}),q&&q.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation();const m=new URL(window.location.href);m.searchParams.set("LH_ItemCondition","3"),window.location.href=m.toString()});const $=(o,m)=>{if(!o){r(`⚠️ No element found for ${m}`);return}document.querySelectorAll(".paymore-listing-highlight").forEach(G=>{G.classList.remove("paymore-listing-highlight")}),o.scrollIntoView({behavior:"smooth",block:"center"}),o.classList.add("paymore-listing-highlight"),setTimeout(()=>{o.classList.remove("paymore-listing-highlight")},3e3),r(`✓ Scrolled to and highlighted ${m}`)},T=c.querySelector('[data-scroll-to="highest"]'),U=c.querySelector('[data-scroll-to="lowest"]'),A=c.querySelector('[data-scroll-to="latest"]');T&&T.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),$(g,"highest price listing")}),U&&U.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),$(u,"lowest price listing")}),A&&A.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),$(k,"most recent listing")})},_=()=>{if(!E){E=!0;try{window.requestAnimationFrame(L)}catch{setTimeout(L,150)}}},D=()=>{if(r("=== Paymore eBay Sold Summary Starting ==="),r("Current URL:",window.location.href),r("Is eBay search page:",window.location.pathname.startsWith("/sch/")),r("Is sold results page:",P()),!document.body){r("Body not ready, retrying..."),setTimeout(D,100);return}chrome.runtime.onMessage.addListener(e=>{e.action==="ebay-summary-settings-changed"&&(r("Received settings change message:",e),_())}),["pushState","replaceState"].forEach(e=>{try{const n=history[e];if(typeof n!="function")return;history[e]=function(...a){const i=n.apply(this,a);return x=!1,_(),i}}catch(n){r(`Failed to wrap history.${e}`,n)}}),window.addEventListener("popstate",()=>{x=!1,_()}),setTimeout(()=>{_()},500)};D()}};function K(){}function f(t,...S){}const M={debug:(...t)=>f(console.debug,...t),log:(...t)=>f(console.log,...t),warn:(...t)=>f(console.warn,...t),error:(...t)=>f(console.error,...t)};return(async()=>{try{return await N.main()}catch(t){throw M.error('The unlisted script "ebay-sold-summary" crashed on startup!',t),t}})()})();
ebaySoldSummary;