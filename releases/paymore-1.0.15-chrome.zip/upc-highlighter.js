var __defProp=Object.defineProperty;var __name=(target,value)=>__defProp(target,"name",{value,configurable:!0});var upcHighlighter=(function(){"use strict";function defineContentScript(definition2){return definition2}__name(defineContentScript,"defineContentScript");const definition={matches:["<all_urls>"],runAt:"document_idle",allFrames:!0,main(){const log=__name((...args)=>{try{console.log("[Paymore UPC Highlighter]",...args)}catch{}},"log"),UPC_REGEX=/\b(\d{12})\b/g,HIGHLIGHT_CSS=`
      .paymore-upc-highlight {
        background-color: rgba(37, 99, 235, 0.15);
        border-bottom: 2px dotted #2563eb;
        cursor: pointer;
        padding: 1px 2px;
        border-radius: 2px;
        transition: all 0.2s ease;
        position: relative;
      }

      .paymore-upc-highlight:hover {
        background-color: rgba(37, 99, 235, 0.25);
        border-bottom-style: solid;
      }

      .paymore-upc-copied {
        background-color: rgba(16, 185, 129, 0.2) !important;
        border-bottom-color: #10b981 !important;
      }

      .paymore-upc-tooltip {
        position: fixed;
        background-color: #111827;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        z-index: 2147483647;
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.2s ease;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
      }

      .paymore-upc-tooltip.show {
        opacity: 1;
      }
    `,injectStyles=__name(()=>{if(!document.getElementById("paymore-upc-highlighter-styles")){const styleElement=document.createElement("style");styleElement.textContent=HIGHLIGHT_CSS,styleElement.id="paymore-upc-highlighter-styles",(document.head||document.documentElement).appendChild(styleElement)}},"injectStyles"),showTooltip=__name((element,text)=>{document.querySelectorAll(".paymore-upc-tooltip").forEach(tooltip2=>{tooltip2.remove()});const tooltip=document.createElement("div");tooltip.className="paymore-upc-tooltip",tooltip.textContent=text,document.body.appendChild(tooltip);const rect=element.getBoundingClientRect(),tooltipRect=tooltip.getBoundingClientRect();let left=rect.left+rect.width/2-tooltipRect.width/2,top=rect.top-tooltipRect.height-8;left<5&&(left=5),left+tooltipRect.width>window.innerWidth-5&&(left=window.innerWidth-tooltipRect.width-5),top<5&&(top=rect.bottom+8),tooltip.style.left=`${left}px`,tooltip.style.top=`${top}px`,setTimeout(()=>{tooltip.classList.add("show")},10),setTimeout(()=>{tooltip.classList.remove("show"),setTimeout(()=>{tooltip.remove()},200)},2e3)},"showTooltip"),copyUPCToClipboard=__name(async(upcCode,element)=>{try{await navigator.clipboard.writeText(upcCode),element.classList.add("paymore-upc-copied"),showTooltip(element,"UPC copied!"),setTimeout(()=>{element.classList.remove("paymore-upc-copied")},2e3),log("UPC code copied to clipboard:",upcCode)}catch(err){log("Failed to copy UPC code:",err),showTooltip(element,"Failed to copy")}},"copyUPCToClipboard"),highlightUPCsInTextNode=__name(textNode=>{const text=textNode.textContent;if(!text||!UPC_REGEX.test(text))return;const fragment=document.createDocumentFragment();let lastIndex=0,match;for(UPC_REGEX.lastIndex=0;(match=UPC_REGEX.exec(text))!==null;){match.index>lastIndex&&fragment.appendChild(document.createTextNode(text.substring(lastIndex,match.index)));const upcElement=document.createElement("span"),upcCode=match[0];upcElement.className="paymore-upc-highlight",upcElement.textContent=upcCode,upcElement.setAttribute("data-upc",upcCode),upcElement.title=`Click to copy UPC: ${upcCode}`,upcElement.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation();const upc=e.currentTarget.getAttribute("data-upc");copyUPCToClipboard(upc,upcElement)}),upcElement.addEventListener("mouseenter",()=>{upcElement.classList.contains("paymore-upc-copied")||showTooltip(upcElement,"Click to copy UPC")}),fragment.appendChild(upcElement),lastIndex=match.index+match[0].length}lastIndex<text.length&&fragment.appendChild(document.createTextNode(text.substring(lastIndex))),fragment.childNodes.length>0&&textNode.parentNode.replaceChild(fragment,textNode)},"highlightUPCsInTextNode"),processElement=__name(element=>{if(!(element.nodeType===Node.ELEMENT_NODE&&(element.tagName==="SCRIPT"||element.tagName==="STYLE"||element.tagName==="NOSCRIPT"||element.classList.contains("paymore-upc-highlight")))){if(element.nodeType===Node.TEXT_NODE){highlightUPCsInTextNode(element);return}element.childNodes&&Array.from(element.childNodes).forEach(processElement)}},"processElement"),scanAndHighlightUPCs=__name(()=>{document.body&&processElement(document.body)},"scanAndHighlightUPCs"),setupMutationObserver=__name(()=>{const observer=new MutationObserver(mutations=>{mutations.some(mutation=>mutation.type==="childList"&&mutation.addedNodes.length>0||mutation.type==="characterData")&&setTimeout(scanAndHighlightUPCs,100)});return document.body&&observer.observe(document.body,{childList:!0,subtree:!0,characterData:!0}),observer},"setupMutationObserver"),checkSettingsEnabled=__name(callback=>{try{chrome.storage.sync.get(["cmdkSettings"],result2=>{if(chrome.runtime.lastError){log("Error checking settings:",chrome.runtime.lastError),callback(!0);return}const enabled=result2.cmdkSettings?.upcHighlighter?.enabled??!0;callback(enabled)})}catch(e){log("Failed to check settings:",e),callback(!0)}},"checkSettingsEnabled"),initializeUPCHighlighter=__name(()=>{checkSettingsEnabled(enabled=>{if(!enabled){log("UPC highlighting is disabled in settings");return}window===window.top&&log("Initializing UPC highlighter"),injectStyles(),setTimeout(scanAndHighlightUPCs,500);const observer=setupMutationObserver();try{chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{if(message.action==="upc-highlighter-settings-changed")if(message.enabled??!0)log("UPC highlighting re-enabled, reloading page"),location.reload();else{document.querySelectorAll(".paymore-upc-highlight").forEach(element=>{const parent=element.parentNode;parent&&parent.replaceChild(document.createTextNode(element.textContent),element)});const styleElement=document.getElementById("paymore-upc-highlighter-styles");styleElement&&styleElement.remove(),observer&&observer.disconnect(),log("UPC highlighting disabled")}return!0})}catch(e){log("Failed to set up message listener:",e)}})},"initializeUPCHighlighter");document.readyState==="loading"?document.addEventListener("DOMContentLoaded",initializeUPCHighlighter):initializeUPCHighlighter()}};function initPlugins(){}__name(initPlugins,"initPlugins");function print(method,...args){}__name(print,"print");const logger={debug:__name((...args)=>print(console.debug,...args),"debug"),log:__name((...args)=>print(console.log,...args),"log"),warn:__name((...args)=>print(console.warn,...args),"warn"),error:__name((...args)=>print(console.error,...args),"error")};return(async()=>{try{return await definition.main()}catch(err){throw logger.error('The unlisted script "upc-highlighter" crashed on startup!',err),err}})()})();
upcHighlighter;