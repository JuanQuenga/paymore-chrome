var __defProp=Object.defineProperty;var __name=(target,value)=>__defProp(target,"name",{value,configurable:!0});var ebaySoldSummary=(function(){"use strict";function defineContentScript(definition2){return definition2}__name(defineContentScript,"defineContentScript");const definition={matches:["https://www.ebay.com/sch/*"],runAt:"document_idle",allFrames:!1,main(){if(!window.location.hostname.includes("ebay.com")||!window.location.pathname.startsWith("/sch/")){console.log("💙 [Paymore eBay Sold Summary] Not on eBay search page, exiting");return}console.log("💙 [Paymore eBay Sold Summary] SCRIPT LOADED - Version 2");const SUMMARY_ID="paymore-ebay-sold-summary",STYLE_ID="paymore-ebay-sold-summary-style";let updateQueued=!1,isDismissed=!1;const log=__name((...args)=>{try{console.log("[Paymore eBay Sold Summary]",...args)}catch{}},"log"),ensureStyles=__name(()=>{if(document.getElementById(STYLE_ID))return;const style=document.createElement("style");style.id=STYLE_ID,style.textContent=`
        #${SUMMARY_ID} {
          width: 100%;
          border: 1px solid #22c55e;
          background: rgba(34, 197, 94, 0.08);
          padding: 14px 18px;
          border-radius: 10px;
          margin: 12px 0 0 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
          color: #0f172a;
          box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08);
          position: relative;
        }
        #${SUMMARY_ID} h2 {
          font-size: 17px;
          margin: 0 0 10px;
          font-weight: 600;
          color: #1e293b;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        #${SUMMARY_ID} h2 img {
          width: 20px;
          height: 20px;
        }
        #${SUMMARY_ID} .paymore-ebay-summary__metrics {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
        }
        #${SUMMARY_ID} .paymore-ebay-summary__metric {
          min-width: 120px;
          background: rgba(255, 255, 255, 0.6);
          padding: 10px 12px;
          border-radius: 8px;
          border: 1px solid rgba(148, 163, 184, 0.4);
        }
        #${SUMMARY_ID} .paymore-ebay-summary__metric--clickable {
          cursor: pointer;
          transition: all 0.2s ease;
        }
        #${SUMMARY_ID} .paymore-ebay-summary__metric--clickable:hover {
          background: rgba(34, 197, 94, 0.15);
          border-color: rgba(34, 197, 94, 0.6);
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(34, 197, 94, 0.2);
        }
        #${SUMMARY_ID} .paymore-ebay-summary__metric--clickable:active {
          transform: translateY(0);
          box-shadow: 0 2px 6px rgba(34, 197, 94, 0.3);
        }
        #${SUMMARY_ID} .paymore-ebay-summary__metric strong {
          display: block;
          font-size: 16px;
          margin-bottom: 4px;
        }
        #${SUMMARY_ID} .paymore-ebay-summary__metric-button {
          min-width: 120px;
          background: linear-gradient(135deg, rgba(34, 197, 94, 0.95), rgba(21, 128, 61, 0.95));
          padding: 12px 16px;
          border-radius: 8px;
          border: 1px solid rgba(34, 197, 94, 0.6);
          cursor: pointer;
          transition: all 0.2s ease;
          text-align: center;
          color: white;
          font-weight: 600;
          font-size: 13px;
          box-shadow: 0 2px 8px rgba(21, 128, 61, 0.2);
          display: flex;
          align-items: center;
          justify-content: center;
        }
        #${SUMMARY_ID} .paymore-ebay-summary__metric-button:hover {
          background: linear-gradient(135deg, rgba(21, 128, 61, 1), rgba(20, 83, 45, 1));
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(21, 128, 61, 0.35);
          border-color: rgba(20, 83, 45, 0.8);
        }
        #${SUMMARY_ID} .paymore-ebay-summary__metric-button:active {
          transform: translateY(0);
          box-shadow: 0 2px 6px rgba(21, 128, 61, 0.3);
        }
        #${SUMMARY_ID} .paymore-ebay-summary__metric-button[disabled] {
          background: rgba(148, 163, 184, 0.3);
          color: rgba(71, 85, 105, 0.6);
          cursor: not-allowed;
          opacity: 0.5;
          pointer-events: none;
        }
        #${SUMMARY_ID} .paymore-ebay-summary__metric-button[disabled]:hover {
          transform: none;
          box-shadow: none;
        }
        #${SUMMARY_ID} .paymore-ebay-summary__dismiss {
          position: absolute;
          top: 10px;
          right: 10px;
          background: rgba(148, 163, 184, 0.2);
          border: 1px solid rgba(148, 163, 184, 0.4);
          border-radius: 6px;
          width: 28px;
          height: 28px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          line-height: 1;
          color: #475569;
          transition: all 0.2s ease;
          z-index: 10;
          pointer-events: auto;
        }
        #${SUMMARY_ID} .paymore-ebay-summary__dismiss:hover {
          background: rgba(239, 68, 68, 0.9);
          border-color: rgba(220, 38, 38, 0.8);
          color: white;
        }
        #${SUMMARY_ID} .paymore-ebay-summary__settings {
          position: absolute;
          top: 10px;
          right: 46px;
          background: rgba(148, 163, 184, 0.2);
          border: 1px solid rgba(148, 163, 184, 0.4);
          border-radius: 6px;
          width: 28px;
          height: 28px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          line-height: 1;
          color: #475569;
          transition: all 0.2s ease;
          z-index: 10;
          pointer-events: auto;
        }
        #${SUMMARY_ID} .paymore-ebay-summary__settings:hover {
          background: rgba(34, 197, 94, 0.9);
          border-color: rgba(21, 128, 61, 0.8);
          color: white;
        }
        #${SUMMARY_ID} .paymore-ebay-summary__meta {
          margin-top: 12px;
          font-size: 12px;
          color: #475569;
        }
        .paymore-listing-highlight {
          animation: paymore-highlight-pulse 1s ease-in-out;
          outline: 3px solid rgba(34, 197, 94, 0.8) !important;
          outline-offset: 4px;
          border-radius: 8px !important;
          background: rgba(34, 197, 94, 0.05) !important;
        }
        @keyframes paymore-highlight-pulse {
          0%, 100% {
            outline-color: rgba(34, 197, 94, 0.8);
            outline-width: 3px;
          }
          50% {
            outline-color: rgba(21, 128, 61, 1);
            outline-width: 5px;
          }
        }
      `,document.head.appendChild(style)},"ensureStyles"),isSoldResultsPage=__name(()=>{try{const url=new URL(window.location.href);if(!/\.ebay\./i.test(url.hostname)||!url.pathname.startsWith("/sch/"))return!1;const soldParam=url.searchParams.get("LH_Sold");return soldParam==="1"||soldParam==="true"}catch{return!1}},"isSoldResultsPage"),parsePrice=__name(text=>{if(!text)return null;let cleaned=text.replace(/\(.*?\)/g,"").replace(/Approximately\s+/i,"").replace(/About\s+/i,"").trim();const rangeSplit=cleaned.split(/\bto\b|-/i);rangeSplit.length>1&&(cleaned=rangeSplit[0]);const match=cleaned.match(/[\d,.]+/);if(!match)return null;const numeric=parseFloat(match[0].replace(/,/g,""));return Number.isFinite(numeric)?numeric:null},"parsePrice"),detectCurrencyPrefix=__name(text=>{if(!text)return"$";const prefix=text.replace(/[\d.,]/g,"").replace(/\s+/g," ").trim();if(prefix)return prefix;const symbolMatch=text.match(/[$\u00a3\u00a5\u20ac]/);return symbolMatch?symbolMatch[0]:"$"},"detectCurrencyPrefix"),formatCurrency=__name((value,prefix)=>{const formatted=value.toLocaleString(void 0,{minimumFractionDigits:2,maximumFractionDigits:2});return`${prefix?prefix+" ":""}${formatted}`.trim()},"formatCurrency"),parseSoldDate=__name(element=>{try{const soldDateElement=element.querySelector(".su-styled-text.positive")||element.querySelector(".s-item__title--tagblock .POSITIVE")||element.querySelector(".s-item__ended-date");if(!soldDateElement)return null;const text=soldDateElement.textContent?.trim();if(!text)return null;const match=text.match(/Sold\s+([A-Za-z]+\s+\d{1,2},\s+\d{4})/i);if(!match)return null;const dateStr=match[1],date=new Date(dateStr);return isNaN(date.getTime())?null:date}catch{return null}},"parseSoldDate"),collectPrices=__name(()=>{const mainResultsContainer=document.querySelector("ul.srp-results.srp-grid")||document.querySelector("#srp-river-results");if(!mainResultsContainer)return log("⚠️ Could not find main results container"),{prices:[],currencyPrefix:"$",mostRecentDate:null,minElement:null,maxElement:null,mostRecentElement:null};log("✓ Found main results container");const allListItems=Array.from(mainResultsContainer.children).filter(child=>child.tagName==="LI");log("Found",allListItems.length,"total <li> elements");const productListings=[];for(let i=0;i<allListItems.length;i++){const item=allListItems[i];if(item.hasAttribute("data-listingid")){productListings.push(item);continue}const classList=item.className||"",textContent=item.textContent||"";if(classList.includes("srp-river-answer--REWRITE_START")||textContent.includes("Results matching fewer words")){log("🛑 STOP: Found 'fewer words' divider at index",i),log("   - Collected",productListings.length,"products before divider");break}log("Skipping divider/notice at index",i)}log("✅ Final count:",productListings.length,"product listings");const priceData=[];let currencyPrefix=null;for(const item of productListings){const priceElement=item.querySelector(".s-card__price")||item.querySelector(".s-item__price")||item.querySelector("[data-test-id='ITEM-PRICE']");if(!priceElement)continue;const text=priceElement.textContent?.trim();if(!text)continue;const value=parsePrice(text);if(value===null)continue;currencyPrefix||(currencyPrefix=detectCurrencyPrefix(text));const soldDate=parseSoldDate(item);priceData.push({value,element:item,date:soldDate})}if(log("💰 Extracted",priceData.length,"prices"),priceData.length===0)return{prices:[],currencyPrefix:currencyPrefix||"$",mostRecentDate:null,minElement:null,maxElement:null,mostRecentElement:null};const minEntry=priceData.reduce((min,curr)=>curr.value<min.value?curr:min),maxEntry=priceData.reduce((max,curr)=>curr.value>max.value?curr:max),entriesWithDates=priceData.filter(entry=>entry.date!==null);let mostRecentEntry=null,mostRecentDate=null;entriesWithDates.length>0&&(mostRecentEntry=entriesWithDates.reduce((latest,current)=>current.date>latest.date?current:latest),mostRecentDate=mostRecentEntry.date);const prices=priceData.map(d=>d.value);return log("📅 Found",entriesWithDates.length,"dates"),{prices,currencyPrefix:currencyPrefix||"$",mostRecentDate,minElement:minEntry.element,maxElement:maxEntry.element,mostRecentElement:mostRecentEntry?.element||null}},"collectPrices"),removeSummary=__name(()=>{const existing=document.getElementById(SUMMARY_ID);existing&&existing.remove()},"removeSummary"),ensureSummaryContainer=__name(()=>{let container=document.getElementById(SUMMARY_ID);if(container)return log("✓ Summary container already exists"),container;const srpControlsRow2=document.querySelector(".srp-controls__row-2");if(log("Searching for .srp-controls__row-2:",srpControlsRow2?"FOUND":"NOT FOUND"),srpControlsRow2)return container=document.createElement("section"),container.id=SUMMARY_ID,srpControlsRow2.appendChild(container),log("✓ Summary container inserted into .srp-controls__row-2"),container;const river=document.getElementById("srp-river-results");return log("Fallback: Searching for #srp-river-results:",river?"FOUND":"NOT FOUND"),!river||!river.parentElement?(log("✗ Cannot insert summary - no suitable parent found"),null):(container=document.createElement("section"),container.id=SUMMARY_ID,river.parentElement.insertBefore(container,river),log("✓ Summary container inserted before #srp-river-results (fallback)"),container)},"ensureSummaryContainer"),renderSummary=__name(async()=>{updateQueued=!1,log("=== renderSummary called ===");try{if(!((await chrome.storage.sync.get(["cmdkSettings"])).cmdkSettings?.ebaySummary?.enabled??!0)){log("✗ eBay Summary feature is disabled in settings"),removeSummary();return}}catch(err){log("⚠️ Failed to check settings, assuming enabled",err)}const isSold=isSoldResultsPage();if(log("Is sold results page?",isSold),!isSold){removeSummary();return}if(isDismissed){log("✗ Summary was dismissed by user, not showing"),removeSummary();return}const{prices,currencyPrefix,mostRecentDate,minElement,maxElement,mostRecentElement}=collectPrices();if(log("Collected prices:",prices.length,"prices found"),!prices.length){log("✗ No prices found, removing summary"),removeSummary();return}ensureStyles();const container=ensureSummaryContainer();if(!container){log("✗ Could not create/find container");return}const sorted=[...prices].sort((a,b)=>a-b),count=prices.length,average=prices.reduce((sum,value)=>sum+value,0)/count,median=count%2===1?sorted[(count-1)/2]:(sorted[count/2-1]+sorted[count/2])/2,min=sorted[0],max=sorted[sorted.length-1];let formattedDate="N/A";if(mostRecentDate){const options={month:"short",day:"numeric",year:"numeric"};formattedDate=mostRecentDate.toLocaleDateString("en-US",options)}const currentCondition=new URL(window.location.href).searchParams.get("LH_ItemCondition"),isOnUsedPage=currentCondition==="4",isOnNewPage=currentCondition==="3",iconUrl=chrome.runtime.getURL("assets/images/brand.png");container.innerHTML=`
        <button type="button" class="paymore-ebay-summary__settings" title="Settings" data-action="settings">⚙</button>
        <button type="button" class="paymore-ebay-summary__dismiss" title="Dismiss" data-action="dismiss">×</button>
        <h2><img src="${iconUrl}" alt="Paymore" /> Paymore Price Summary</h2>
        <div class="paymore-ebay-summary__metrics">
          <div class="paymore-ebay-summary__metric">
            <strong>Average</strong>
            <span>${formatCurrency(average,currencyPrefix)}</span>
          </div>
          <div class="paymore-ebay-summary__metric">
            <strong>Median</strong>
            <span>${formatCurrency(median,currencyPrefix)}</span>
          </div>
          <div class="paymore-ebay-summary__metric paymore-ebay-summary__metric--clickable" data-scroll-to="highest" title="Click to scroll to listing">
            <strong>Highest</strong>
            <span>${formatCurrency(max,currencyPrefix)}</span>
          </div>
          <div class="paymore-ebay-summary__metric paymore-ebay-summary__metric--clickable" data-scroll-to="lowest" title="Click to scroll to listing">
            <strong>Lowest</strong>
            <span>${formatCurrency(min,currencyPrefix)}</span>
          </div>
          <div class="paymore-ebay-summary__metric">
            <strong>Listings</strong>
            <span>${count}</span>
          </div>
          <div class="paymore-ebay-summary__metric paymore-ebay-summary__metric--clickable" data-scroll-to="latest" title="Click to scroll to listing">
            <strong>Last Sold</strong>
            <span>${formattedDate}</span>
          </div>
          <div class="paymore-ebay-summary__metric-button" data-action="view-used" ${isOnUsedPage?"disabled":""}>
            View Used
          </div>
          <div class="paymore-ebay-summary__metric-button" data-action="view-new" ${isOnNewPage?"disabled":""}>
            View New
          </div>
        </div>
        <div class="paymore-ebay-summary__meta">
          Based on ${count} sold listings detected on this page. Apply filters or refresh to recalculate.
        </div>
      `;const settingsBtn=container.querySelector('[data-action="settings"]'),dismissBtn=container.querySelector('[data-action="dismiss"]'),usedBtn=container.querySelector('[data-action="view-used"]'),newBtn=container.querySelector('[data-action="view-new"]');settingsBtn&&settingsBtn.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),log("Settings button clicked"),chrome.runtime.sendMessage({action:"open-settings",section:"ebay"})}),dismissBtn&&dismissBtn.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),log("Dismiss button clicked"),isDismissed=!0,removeSummary()}),usedBtn&&usedBtn.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation();const url2=new URL(window.location.href);url2.searchParams.set("LH_ItemCondition","4"),window.location.href=url2.toString()}),newBtn&&newBtn.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation();const url2=new URL(window.location.href);url2.searchParams.set("LH_ItemCondition","3"),window.location.href=url2.toString()});const scrollToAndHighlight=__name((element,metricName)=>{if(!element){log(`⚠️ No element found for ${metricName}`);return}document.querySelectorAll(".paymore-listing-highlight").forEach(el=>{el.classList.remove("paymore-listing-highlight")}),element.scrollIntoView({behavior:"smooth",block:"center"}),element.classList.add("paymore-listing-highlight"),setTimeout(()=>{element.classList.remove("paymore-listing-highlight")},3e3),log(`✓ Scrolled to and highlighted ${metricName}`)},"scrollToAndHighlight"),highestMetric=container.querySelector('[data-scroll-to="highest"]'),lowestMetric=container.querySelector('[data-scroll-to="lowest"]'),latestMetric=container.querySelector('[data-scroll-to="latest"]');highestMetric&&highestMetric.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),scrollToAndHighlight(maxElement,"highest price listing")}),lowestMetric&&lowestMetric.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),scrollToAndHighlight(minElement,"lowest price listing")}),latestMetric&&latestMetric.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),scrollToAndHighlight(mostRecentElement,"most recent listing")})},"renderSummary"),scheduleUpdate=__name(()=>{if(!updateQueued){updateQueued=!0;try{window.requestAnimationFrame(renderSummary)}catch{setTimeout(renderSummary,150)}}},"scheduleUpdate"),start=__name(()=>{if(log("=== Paymore eBay Sold Summary Starting ==="),log("Current URL:",window.location.href),log("Is eBay search page:",window.location.pathname.startsWith("/sch/")),log("Is sold results page:",isSoldResultsPage()),!document.body){log("Body not ready, retrying..."),setTimeout(start,100);return}chrome.runtime.onMessage.addListener(message=>{message.action==="ebay-summary-settings-changed"&&(log("Received settings change message:",message),scheduleUpdate())}),["pushState","replaceState"].forEach(method=>{try{const original=history[method];if(typeof original!="function")return;history[method]=function(...args){const result2=original.apply(this,args);return isDismissed=!1,scheduleUpdate(),result2}}catch(err){log(`Failed to wrap history.${method}`,err)}}),window.addEventListener("popstate",()=>{isDismissed=!1,scheduleUpdate()}),setTimeout(()=>{scheduleUpdate()},500)},"start");start()}};function initPlugins(){}__name(initPlugins,"initPlugins");function print(method,...args){}__name(print,"print");const logger={debug:__name((...args)=>print(console.debug,...args),"debug"),log:__name((...args)=>print(console.log,...args),"log"),warn:__name((...args)=>print(console.warn,...args),"warn"),error:__name((...args)=>print(console.error,...args),"error")};return(async()=>{try{return await definition.main()}catch(err){throw logger.error('The unlisted script "ebay-sold-summary" crashed on startup!',err),err}})()})();
ebaySoldSummary;