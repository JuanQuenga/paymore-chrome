import"./_virtual_wxt-html-plugins-DPbbfBKe.js";console.log("Offscreen: placeholder loaded");chrome.runtime.onMessage.addListener((r,s,e)=>(e({success:!1,error:"offscreen_placeholder"}),!0));
